package com.window.tlp;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.ActionMode;
import android.support.v7.widget.ActivityChooserView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

//import com.facebook.Session;
//import com.facebook.SessionState;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.facebook.share.model.AppInviteContent;
import com.facebook.share.widget.AppInviteDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;


public class MainActivity extends AppCompatActivity {
    public static CallbackManager callbackmanager;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.main);
        //setContentView(R.layout.main);
        //onBackPressed();
        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

//        if (facebook.isSessionValid())
//            startActivity(new Intent(MainActivity.this, PhotoIntentActivity.class));

        Button invite = (Button) findViewById(R.id.button);
        Button loginButton = (Button) findViewById(R.id.login_button);
        loginButton = (LoginButton) findViewById(R.id.login_button);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onFblogin();
//                Intent intent = new Intent(MainActivity.this,Recordvideo.class);
//                startActivity(intent);

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.action_take) {
//            Intent intent = new Intent(MainActivity.this,PhotoIntentActivity.class);
//            startActivity(intent);
            onFblogin();
            return true;
        }

        if (id == R.id.action_invite) {
//            Intent intent = new Intent(MainActivity.this,ProceedActivity.class);
//            startActivity(intent);
            onFblogin();
            return true;
        }

        if (id == R.id.action_pending) {
//            Intent intent = new Intent(MainActivity.this,PendingLaughActivity.class);
//            startActivity(intent);
            onFblogin();
            return true;
        }

        if (id == R.id.action_report) {
//            Intent intent = new Intent(NewLaughActivity.this,PhotoIntentActivity.class);
//            startActivity(intent);
            onFblogin();
            return true;
        }
        if (id == R.id.action_message) {
            return true;
        }

        if (id == R.id.action_share) {
            return true;
        }

        if (id == R.id.action_aboutus) {
            Intent intent = new Intent(MainActivity.this,AboutusActivity.class);
           startActivity(intent);
            return true;
        }



        return super.onOptionsItemSelected(item);
    }



    private void onFblogin() {
        callbackmanager = CallbackManager.Factory.create();

        // Set permissions
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("email", "user_photos", "public_profile"));

        LoginManager.getInstance().registerCallback(callbackmanager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {


                        System.out.println("Success");
                        GraphRequest.newMeRequest(
                                loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                                    @Override
                                    public void onCompleted(JSONObject json, GraphResponse response) {
                                        if (response.getError() != null) {
                                            // handle error
                                            System.out.println("ERROR");
                                        } else {
                                            Intent intent = new Intent(MainActivity.this, NewLaughActivity.class);
                                            startActivity(intent);
                                            System.out.println("Success");
                                            try {
//                                                String jsonresult = String.valueOf(json);
//                                                Log.e("JSON Results","" + jsonresult);


                                               /* String jsonresult = String.valueOf(json);
                                                Log.e("JSON Result","" + jsonresult);

                                                String str_email = json.getString("email");
                                                Log.d("email",""+str_email);
                                                String str_id = json.getString("id");
                                                String str_firstname = json.getString("first_name");
                                                String str_lastname = json.getString("last_name");*/


                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                        }


                                    }


                                }).executeAsync();



                        //Bundle parameters = new Bundle();
                        //parameters.putString("fields", "id,name,email,gender, birthday");
                        //request.setParameters(parameters);
                        //request.executeAsync();

            //            finish();



                    }


                    @Override
                    public void onCancel() {
                    }

                    @Override
                    public void onError(FacebookException error) {
                    }
                });


    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        callbackmanager.onActivityResult(requestCode, resultCode, data);

//        if (resultCode == RESULT_OK) {
//            Intent intent = new Intent(MainActivity.this, PhotoIntentActivity.class);
//            startActivity(intent);
//            //finish();
//        }

//        if (resultCode == RESULT_OK) {
//
//            Intent intent = new Intent(MainActivity.this, PhotoIntentActivity.class);
//            startActivity(intent);
//            //finish();
//        }
    }


}