package com.window.tlp;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

/**
 * Created by Creativedemons on 1/1/2007.
 */
public class PhotoIntentActivity extends AppCompatActivity {
    VideoView mVideoview;
    private Uri mVideoUri;
    Button vidBtn, proceed1, recordagain;
    private static final int ACTION_TAKE_VIDEO = 3;
    private Toolbar mToolbar;
    MediaRecorder   mRecorder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main1);

//        recordagain.setVisibility(View.INVISIBLE);
//        proceed1.setVisibility(View.INVISIBLE);
        recordagain = (Button) findViewById(R.id.recagain);
        recordagain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 10);
                startActivityForResult(intent, ACTION_TAKE_VIDEO);
            }
        });

        proceed1 = (Button) findViewById(R.id.proceed);
        proceed1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PhotoIntentActivity.this, ProceedActivity.class);
                startActivity(intent);
            }
        });
        vidBtn = (Button) findViewById(R.id.btnIntendV);
        mVideoview = (VideoView) findViewById(R.id.videoView1);

        vidBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 8);
                startActivityForResult(intent, ACTION_TAKE_VIDEO);
            }
        });


        mVideoview.setMediaController(new MediaController(this));
        mVideoview.requestFocus();

        mVideoview.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
            }
        });

        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


//        MediaRecorder   mRecorder = new MediaRecorder();
//        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
//        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
//        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
//        mRecorder.setOutputFile("/dev/null");
//        //mRecorder.prepare();
//        mRecorder.start();
    }


//    public double getAmplitude() {
//        if (mRecorder != null)
//            return  (mRecorder.getMaxAmplitude());
//        else
//            return 0;
//
//    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (resultCode == RESULT_OK) {
            mVideoUri = data.getData();
            mVideoview.setVideoURI(mVideoUri);
            mVideoview.start();

//            recordagain.setVisibility(View.VISIBLE);
//            proceed1.setVisibility(View.VISIBLE);

        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        if (id == R.id.action_invite) {
            Intent intent = new Intent(PhotoIntentActivity.this,ProceedActivity.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.action_pending) {
            Intent intent = new Intent(PhotoIntentActivity.this,PendingLaughActivity.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.action_report) {
            Intent intent = new Intent(PhotoIntentActivity.this,ProjectReportActivity.class);
            startActivity(intent);
            return true;
        }

        if (id == R.id.action_aboutus) {
            Intent intent = new Intent(PhotoIntentActivity.this,AboutusActivity.class);
            startActivity(intent);
            return true;
        }
        if (id == R.id.action_message) {
            return true;
        }

        if (id == R.id.action_share) {
            return true;
        }



        return super.onOptionsItemSelected(item);
    }



}